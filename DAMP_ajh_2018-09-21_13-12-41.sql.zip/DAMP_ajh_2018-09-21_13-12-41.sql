-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: DAMP_ajh
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `DAMP_ajh`
--


--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  `cost` float NOT NULL,
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  `url` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=384 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (318,'Royal Academy of Music',759.67,51.5233,-0.151829,'https://www.thecompleteuniversityguide.co.uk/royal-academy-of-music/'),(347,'University of West London',1050,51.5069,-0.303358,'https://www.thecompleteuniversityguide.co.uk/west-london/'),(346,'University of Warwick',866.67,52.3801,-1.5617,'https://www.thecompleteuniversityguide.co.uk/warwick/'),(345,'University of the Arts London',1224,51.5177,-0.116398,'https://www.thecompleteuniversityguide.co.uk/university-of-the-arts/'),(344,'The University of Law',0,51.2245,-0.583119,'https://www.thecompleteuniversityguide.co.uk/university-of-law/'),(343,'UCA Farnham',500,51.2151,-0.805373,'https://www.thecompleteuniversityguide.co.uk/university-for-the-creative-arts/'),(342,'University College of Estate Management',0,51.4532,-0.963565,'https://www.thecompleteuniversityguide.co.uk/university-college-of-estate-management/'),(341,'University College London',0,51.5246,-0.13404,'https://www.thecompleteuniversityguide.co.uk/university-college-london/'),(340,'UCFB Wembley',0,51.5572,-0.279501,'https://www.thecompleteuniversityguide.co.uk/university-college-of-football-business-(ucfb)/'),(339,'Trinity Laban – Faculty of Dance',0,51.4834,-0.006746,'https://www.thecompleteuniversityguide.co.uk/trinity-laban-conservatoire-of-music-and-dance/'),(338,'Teesside University',498.33,54.5708,-1.23522,'https://www.thecompleteuniversityguide.co.uk/teesside/'),(337,'University of Sussex',497.33,50.8671,-0.087914,'https://www.thecompleteuniversityguide.co.uk/sussex/'),(336,'The University of Surrey',1451.67,51.2422,-0.590542,'https://www.thecompleteuniversityguide.co.uk/surrey/'),(335,'University of Sunderland in London',642.75,51.5002,-0.0142346,'https://www.thecompleteuniversityguide.co.uk/sunderland/'),(334,'University of Suffolk',0,52.0522,1.16334,'https://www.thecompleteuniversityguide.co.uk/suffolk/'),(333,'Staffordshire University',406.25,53.0091,-2.17614,'https://www.thecompleteuniversityguide.co.uk/staffordshire/'),(332,'St Mary\'s University',806.67,51.437,-0.33507,'https://www.thecompleteuniversityguide.co.uk/st-marys/'),(331,'St George\'s',736.67,51.4272,-0.174503,'https://www.thecompleteuniversityguide.co.uk/st-georges/'),(330,'University of Southampton',594.75,50.9357,-1.39664,'https://www.thecompleteuniversityguide.co.uk/southampton/'),(329,'Solent University',667.33,50.9086,-1.40157,'https://www.thecompleteuniversityguide.co.uk/solent/'),(328,'SOAS University of London',0,51.5224,-0.129259,'https://www.thecompleteuniversityguide.co.uk/soas-university-of-london/'),(327,'Sheffield Hallam University',0,53.3782,-1.46589,'https://www.thecompleteuniversityguide.co.uk/sheffield-hallam/'),(326,'The University of Sheffield',699.42,53.3809,-1.48795,'https://www.thecompleteuniversityguide.co.uk/sheffield/'),(325,'University of Salford',520.58,53.4846,-2.27076,'https://www.thecompleteuniversityguide.co.uk/salford/'),(324,'Royal Veterinary College',0,51.5367,-0.13397,'https://www.thecompleteuniversityguide.co.uk/royal-veterinary-college/'),(323,'Royal Northern College of Music',0,53.4685,-2.23674,'https://www.thecompleteuniversityguide.co.uk/royal-northern-college-of-music/'),(322,'Royal Holloway',548.25,51.4257,-0.563062,'https://www.thecompleteuniversityguide.co.uk/royal-holloway/'),(321,'Royal College of Music',0,51.4994,-0.177087,'https://www.thecompleteuniversityguide.co.uk/royal-college-of-music/'),(320,'The Royal Central School of Speech and Drama',0,51.5443,-0.174204,'https://www.thecompleteuniversityguide.co.uk/royal-central-school-of-speech-and-drama/'),(319,'Royal Agricultural University',680.58,51.7093,-1.99465,'https://www.thecompleteuniversityguide.co.uk/royal-agricultural-university/'),(317,'Rose Bruford College of Theatre and Performance',845,51.4391,0.106768,'https://www.thecompleteuniversityguide.co.uk/rose-bruford-college/'),(316,'University of Roehampton',761.75,51.458,-0.243287,'https://www.thecompleteuniversityguide.co.uk/roehampton/'),(315,'University of Reading',0,51.4414,-0.941816,'https://www.thecompleteuniversityguide.co.uk/reading/'),(314,'Ravensbourne',815,51.5017,0.0057496,'https://www.thecompleteuniversityguide.co.uk/ravensbourne/'),(313,'Queen Mary University of London ',0,51.5241,-0.0403745,'https://www.thecompleteuniversityguide.co.uk/queen-mary/'),(312,'University of Portsmouth',513.33,50.7952,-1.09359,'https://www.thecompleteuniversityguide.co.uk/portsmouth/'),(311,'Plymouth Marjon University',476.67,50.4211,-4.11043,'https://www.thecompleteuniversityguide.co.uk/plymouth-marjon/'),(310,'University of Plymouth',582.5,50.3759,-4.13958,'https://www.thecompleteuniversityguide.co.uk/plymouth/'),(309,'Pearson Business School',0,51.5167,-0.123263,'https://www.thecompleteuniversityguide.co.uk/pearson-college/'),(308,'Oxford Brookes University',740.42,51.755,-1.22423,'https://www.thecompleteuniversityguide.co.uk/oxford-brookes/'),(307,'University of Oxford',0,51.7581,-1.26217,'https://www.thecompleteuniversityguide.co.uk/oxford/'),(306,'The Open University',0,52.025,-0.708403,'https://www.thecompleteuniversityguide.co.uk/the-open-university/'),(305,'Nottingham Trent University',0,52.9585,-1.15268,'https://www.thecompleteuniversityguide.co.uk/nottingham-trent/'),(304,'The University of Nottingham',649,52.9387,-1.19517,'https://www.thecompleteuniversityguide.co.uk/nottingham/'),(303,'Norwich University of the Arts',651.67,52.6303,1.2967,'https://www.thecompleteuniversityguide.co.uk/norwich-university-of-the-arts/'),(302,'Northumbria University',553.58,54.9768,-1.6075,'https://www.thecompleteuniversityguide.co.uk/northumbria/'),(301,'University of Northampton',553,52.2735,-0.882601,'https://www.thecompleteuniversityguide.co.uk/northampton/'),(300,'Newman University ',0,52.433,-1.99421,'https://www.thecompleteuniversityguide.co.uk/newman-university/'),(299,'Newcastle University',749.67,54.979,-1.61358,'https://www.thecompleteuniversityguide.co.uk/newcastle/'),(298,'New College of the Humanities',0,51.5194,-0.130519,'https://www.thecompleteuniversityguide.co.uk/new-college-of-the-humanities/'),(297,'Middlesex University',585,51.5899,-0.229365,'https://www.thecompleteuniversityguide.co.uk/middlesex/'),(296,'Medway School of Pharmacy',0,51.3973,0.539073,'https://www.thecompleteuniversityguide.co.uk/medway-school-of-pharmacy/'),(295,'Manchester Metropolitan University',896.75,53.4711,-2.23862,'https://www.thecompleteuniversityguide.co.uk/manchester-metropolitan/'),(294,'The University of Manchester',619.58,53.4669,-2.23388,'https://www.thecompleteuniversityguide.co.uk/manchester/'),(293,'Loughborough University ',582.08,52.7692,-1.22463,'https://www.thecompleteuniversityguide.co.uk/loughborough/'),(292,'London South Bank University',0,51.4982,-0.102086,'https://www.thecompleteuniversityguide.co.uk/london-south-bank/'),(291,'LSE',2457,51.5144,-0.117377,'https://www.thecompleteuniversityguide.co.uk/london-school-of-economics/'),(290,'London Metropolitan University',0,51.5516,-0.110715,'https://www.thecompleteuniversityguide.co.uk/london-metropolitan/'),(289,'The London Institute of Banking & Finance',0,51.5096,-0.084088,'https://www.thecompleteuniversityguide.co.uk/london-institute-of-banking-and-finance/'),(288,'Liverpool John Moores University',697.67,53.4093,-2.9906,'https://www.thecompleteuniversityguide.co.uk/liverpool-john-moores/'),(287,'The Liverpool Institute for Performing Arts',0,53.3996,-2.97231,'https://www.thecompleteuniversityguide.co.uk/liverpool-institute-for-performing-arts/'),(286,'Liverpool Hope University',369,53.3908,-2.8923,'https://www.thecompleteuniversityguide.co.uk/liverpool-hope/'),(285,'University of Liverpool',712.75,53.4059,-2.96557,'https://www.thecompleteuniversityguide.co.uk/liverpool/'),(284,'University of Lincoln',0,53.2279,-0.550193,'https://www.thecompleteuniversityguide.co.uk/lincoln/'),(283,'University of Leicester',0,52.6211,-1.12463,'https://www.thecompleteuniversityguide.co.uk/leicester/'),(282,'Leeds Trinity University ',450.25,53.8488,-1.64692,'https://www.thecompleteuniversityguide.co.uk/leeds-trinity/'),(281,'Leeds Beckett University',816.58,53.8036,-1.54743,'https://www.thecompleteuniversityguide.co.uk/leeds-beckett/'),(280,'Leeds Arts University',513.33,53.8088,-1.55158,'https://www.thecompleteuniversityguide.co.uk/leeds-arts-university/'),(279,'University of Leeds',0,53.8067,-1.55503,'https://www.thecompleteuniversityguide.co.uk/leeds/'),(278,'Lancaster University',797.33,54.0105,-2.78691,'https://www.thecompleteuniversityguide.co.uk/lancaster/'),(277,'Kingston University',1375,51.4032,-0.303488,'https://www.thecompleteuniversityguide.co.uk/kingston/'),(276,'King\'s College London',1695.75,51.5107,-0.1169,'https://www.thecompleteuniversityguide.co.uk/kings-college-london/'),(275,'The University of Kent',624.58,51.2985,1.07089,'https://www.thecompleteuniversityguide.co.uk/kent/'),(274,'Keele University',753.08,53.004,-2.2746,'https://www.thecompleteuniversityguide.co.uk/keele/'),(273,'Imperial College London',1187.33,51.4988,-0.174877,'https://www.thecompleteuniversityguide.co.uk/imperial-college-london/'),(272,'The University of Hull',773.67,53.7737,-0.368078,'https://www.thecompleteuniversityguide.co.uk/hull/'),(271,'University of Huddersfield',476.67,53.6428,-1.77809,'https://www.thecompleteuniversityguide.co.uk/huddersfield/'),(270,'University of Hertfordshire',794.92,51.7529,-0.242173,'https://www.thecompleteuniversityguide.co.uk/hertfordshire/'),(269,'Harper Adams University',497.42,52.7794,-2.42713,'https://www.thecompleteuniversityguide.co.uk/harper-adams/'),(268,'Guildhall School of Music and Drama',741,51.5197,-0.0908734,'https://www.thecompleteuniversityguide.co.uk/guildhall-school-of-music-and-drama/'),(267,'University of Greenwich',910.5,51.484,-0.00499,'https://www.thecompleteuniversityguide.co.uk/greenwich/'),(266,'Goldsmiths',1243.67,51.4743,-0.035408,'https://www.thecompleteuniversityguide.co.uk/goldsmiths/'),(265,'University of Gloucestershire',823.33,51.8871,-2.08873,'https://www.thecompleteuniversityguide.co.uk/gloucestershire/'),(264,'Falmouth University',631.17,50.1492,-5.07068,'https://www.thecompleteuniversityguide.co.uk/falmouth-university/'),(263,'University of Exeter',1091.67,50.7352,-3.53428,'https://www.thecompleteuniversityguide.co.uk/exeter/'),(262,'University of Essex',780,51.8777,0.947207,'https://www.thecompleteuniversityguide.co.uk/essex/'),(261,'Edge Hill University',424.17,53.5597,-2.87385,'https://www.thecompleteuniversityguide.co.uk/edge-hill/'),(260,'University of East London',0,51.5076,0.0650809,'https://www.thecompleteuniversityguide.co.uk/east-london-uel/'),(259,'University of East Anglia',0,52.6219,1.23918,'https://www.thecompleteuniversityguide.co.uk/east-anglia/'),(258,'Durham University',656.92,54.7686,-1.57213,'https://www.thecompleteuniversityguide.co.uk/durham/'),(257,'University of Derby',0,52.9385,-1.49652,'https://www.thecompleteuniversityguide.co.uk/derby/'),(256,'De Montfort University',618.42,52.6298,-1.13937,'https://www.thecompleteuniversityguide.co.uk/de-montfort/'),(255,'University of Cumbria',0,54.8909,-2.92223,'https://www.thecompleteuniversityguide.co.uk/cumbria/'),(254,'Coventry University',566.17,52.4072,-1.50375,'https://www.thecompleteuniversityguide.co.uk/coventry/'),(253,'The Courtauld Institute of Art',0,51.5116,-0.117395,'https://www.thecompleteuniversityguide.co.uk/the-courtauld-institute-of-art/'),(252,'Conservatoire for Dance and Drama',0,51.5258,-0.128796,'https://www.thecompleteuniversityguide.co.uk/conservatoire-for-dance-and-drama/'),(251,'City',0,51.5278,-0.102545,'https://www.thecompleteuniversityguide.co.uk/city-university-london/'),(250,'University of Chichester',732.33,50.845,-0.772892,'https://www.thecompleteuniversityguide.co.uk/chichester/'),(249,'University of Chester',710.67,53.2003,-2.89917,'https://www.thecompleteuniversityguide.co.uk/chester/'),(248,'University of Central Lancashire',476.67,53.7645,-2.70835,'https://www.thecompleteuniversityguide.co.uk/central-lancashire/'),(247,'Canterbury Christ Church University',0,51.2779,1.09066,'https://www.thecompleteuniversityguide.co.uk/canterbury-christ-church/'),(246,'University of Cambridge',0,52.2004,0.120066,'https://www.thecompleteuniversityguide.co.uk/cambridge/'),(245,'Buckinghamshire New University',646.42,51.6279,-0.753404,'https://www.thecompleteuniversityguide.co.uk/buckinghamshire-new/'),(244,'The University of Buckingham',816.67,51.9962,-0.991869,'https://www.thecompleteuniversityguide.co.uk/buckingham/'),(243,'Brunel University London',0,51.5329,-0.471229,'https://www.thecompleteuniversityguide.co.uk/brunel/'),(242,'University of Bristol',689.5,51.4578,-2.60844,'https://www.thecompleteuniversityguide.co.uk/bristol/'),(240,'University of Bradford',417.25,53.7908,-1.76346,'https://www.thecompleteuniversityguide.co.uk/bradford/'),(241,'University of Brighton',780,50.8421,-0.119365,'https://www.thecompleteuniversityguide.co.uk/brighton/'),(239,'BPP University',0,51.514,-0.0809164,'https://www.thecompleteuniversityguide.co.uk/bpp-university/'),(238,'Bournemouth University',825,50.7424,-1.89564,'https://www.thecompleteuniversityguide.co.uk/bournemouth/'),(237,'University of Bolton',0,53.5729,-2.43793,'https://www.thecompleteuniversityguide.co.uk/bolton/'),(236,'Bishop Grosseteste University',379.83,53.2438,-0.536425,'https://www.thecompleteuniversityguide.co.uk/bishop-grosseteste/'),(235,'Birmingham City University',650,52.4823,-1.88876,'https://www.thecompleteuniversityguide.co.uk/birmingham-city/'),(234,'University of Birmingham',669.67,52.4508,-1.93051,'https://www.thecompleteuniversityguide.co.uk/birmingham/'),(233,'Birkbeck',0,51.522,-0.130462,'https://www.thecompleteuniversityguide.co.uk/birkbeck/'),(232,'University of Bedfordshire',0,51.8776,-0.409962,'https://www.thecompleteuniversityguide.co.uk/bedfordshire/'),(231,'Bath Spa University',786.5,51.3756,-2.43826,'https://www.thecompleteuniversityguide.co.uk/bath-spa/'),(230,'University of Bath',0,51.3781,-2.32726,'https://www.thecompleteuniversityguide.co.uk/bath/'),(229,'Aston University',0,52.4869,-1.88822,'https://www.thecompleteuniversityguide.co.uk/aston/'),(228,'Arts University Bournemouth ',758.33,50.741,-1.89793,'https://www.thecompleteuniversityguide.co.uk/arts-university-bournemouth/'),(227,'Arden University',0,52.3695,-1.46756,'https://www.thecompleteuniversityguide.co.uk/arden/'),(383,'University of Sunderland',642.75,54.9045,-1.3913,'https://www.thecompleteuniversityguide.co.uk/sunderland/'),(226,'Anglia Ruskin University',0,51.7423,0.473356,'https://www.thecompleteuniversityguide.co.uk/anglia-ruskin/'),(348,'University of the West of England',0,51.5001,-2.54753,'https://www.thecompleteuniversityguide.co.uk/west-of-england/'),(349,'University of Westminster',862.5,51.5206,-0.141079,'https://www.thecompleteuniversityguide.co.uk/westminster/'),(350,'University of Winchester',745.25,51.0594,-1.32599,'https://www.thecompleteuniversityguide.co.uk/winchester/'),(351,'University of Wolverhampton',317.58,52.5872,-2.12753,'https://www.thecompleteuniversityguide.co.uk/wolverhampton/'),(352,'University of Worcester',516.75,52.197,-2.24283,'https://www.thecompleteuniversityguide.co.uk/worcester/'),(353,'Writtle University College',581.67,51.7366,0.42865,'https://www.thecompleteuniversityguide.co.uk/writtle-university-college/'),(354,'University of York',660,53.9455,-1.05617,'https://www.thecompleteuniversityguide.co.uk/york/'),(355,'York St John University',653.17,53.9649,-1.0801,'https://www.thecompleteuniversityguide.co.uk/york-st-john/'),(356,'Queen\'s University Belfast',554.17,54.5844,-5.93405,'https://www.thecompleteuniversityguide.co.uk/queens-belfast/'),(357,'Ulster University',0,55.1498,-6.67516,'https://www.thecompleteuniversityguide.co.uk/ulster/'),(358,'University of Aberdeen',0,57.1648,-2.10153,'https://www.thecompleteuniversityguide.co.uk/aberdeen/'),(359,'Abertay University',430,56.4633,-2.97392,'https://www.thecompleteuniversityguide.co.uk/abertay/'),(360,'University of Dundee',468,56.4582,-2.98214,'https://www.thecompleteuniversityguide.co.uk/dundee/'),(361,'University of Edinburgh',773.67,55.9445,-3.18924,'https://www.thecompleteuniversityguide.co.uk/edinburgh/'),(362,'Edinburgh Napier University',0,55.9246,-3.28875,'https://www.thecompleteuniversityguide.co.uk/edinburgh-napier/'),(363,'University of Glasgow',594.67,55.8721,-4.2882,'https://www.thecompleteuniversityguide.co.uk/glasgow/'),(364,'Glasgow Caledonian University',0,55.8662,-4.2508,'https://www.thecompleteuniversityguide.co.uk/glasgow-caledonian/'),(365,'Glasgow School of Art',0,55.8661,-4.26369,'https://www.thecompleteuniversityguide.co.uk/glasgow-school-of-art/'),(366,'Heriot-Watt University',732.33,55.9097,-3.32035,'https://www.thecompleteuniversityguide.co.uk/heriot-watt/'),(367,'University of the Highlands and Islands',0,57.471,-4.23063,'https://www.thecompleteuniversityguide.co.uk/university-of-the-highlands-and-islands/'),(368,'Queen Margaret University',413.33,55.9303,-3.07394,'https://www.thecompleteuniversityguide.co.uk/queen-margaret/'),(369,'The Robert Gordon University',854.17,57.1185,-2.14076,'https://www.thecompleteuniversityguide.co.uk/robert-gordon/'),(370,'Royal Conservatoire of Scotland',0,55.8662,-4.25759,'https://www.thecompleteuniversityguide.co.uk/royal-conservatoire-of-scotland/'),(371,'University of St Andrews',680.83,56.3426,-2.79723,'https://www.thecompleteuniversityguide.co.uk/st-andrews/'),(372,'University of Stirling',503.5,56.1492,-3.92679,'https://www.thecompleteuniversityguide.co.uk/stirling/'),(373,'University of Strathclyde',628.33,55.8621,-4.24229,'https://www.thecompleteuniversityguide.co.uk/strathclyde/'),(374,'University of the West of Scotland',0,55.8433,-4.42996,'https://www.thecompleteuniversityguide.co.uk/west-of-scotland/'),(375,'Aberystwyth University',565.5,52.4181,-4.06569,'https://www.thecompleteuniversityguide.co.uk/aberystwyth/'),(376,'Bangor University',0,53.2295,-4.12999,'https://www.thecompleteuniversityguide.co.uk/bangor/'),(377,'Cardiff University',488.92,51.4866,-3.17886,'https://www.thecompleteuniversityguide.co.uk/cardiff/'),(378,'Cardiff Metropolitan University',0,51.4962,-3.21314,'https://www.thecompleteuniversityguide.co.uk/cardiff-metropolitan-university-uwic/'),(379,'University of South Wales',559,51.5895,-3.32754,'https://www.thecompleteuniversityguide.co.uk/university-of-south-wales/'),(380,'Swansea University',650,51.6106,-3.97639,'https://www.thecompleteuniversityguide.co.uk/swansea/'),(381,'University of Wales Trinity Saint David',427.5,51.8583,-4.32871,'https://www.thecompleteuniversityguide.co.uk/university-of-wales-trinity-saint-david/'),(382,'Wrexham Glyndwr University',420.33,53.0526,-3.00617,'https://www.thecompleteuniversityguide.co.uk/glyndwr/');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities.2018.08.06`
--

DROP TABLE IF EXISTS `cities.2018.08.06`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities.2018.08.06` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  `cost` float NOT NULL,
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  `url` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=225 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities.2018.08.06`
--

LOCK TABLES `cities.2018.08.06` WRITE;
/*!40000 ALTER TABLE `cities.2018.08.06` DISABLE KEYS */;
INSERT INTO `cities.2018.08.06` VALUES (110,'Wrexham Glyndwr University',420.33,53.0537,-3.00345,'https://www.thecompleteuniversityguide.co.uk/weexham-glyndwr'),(112,'Anglia Ruskin University',0,51.7423,0.473356,'https://www.thecompleteuniversityguide.co.uk/anglia-ruskin/'),(113,'Arden University',0,52.3695,-1.46756,'https://www.thecompleteuniversityguide.co.uk/arden/'),(114,'Arts University Bournemouth ',758.33,50.741,-1.89793,'https://www.thecompleteuniversityguide.co.uk/arts-university-bournemouth/'),(115,'Aston University',0,52.4869,-1.88822,'https://www.thecompleteuniversityguide.co.uk/aston/'),(116,'University of Bath',0,51.3781,-2.32726,'https://www.thecompleteuniversityguide.co.uk/bath/'),(117,'Bath Spa University',786.5,51.3756,-2.43826,'https://www.thecompleteuniversityguide.co.uk/bath-spa/'),(118,'University of Bedfordshire',0,51.8776,-0.409962,'https://www.thecompleteuniversityguide.co.uk/bedfordshire/'),(119,'Birkbeck',0,51.522,-0.130462,'https://www.thecompleteuniversityguide.co.uk/birkbeck/'),(120,'University of Birmingham',669.67,52.4508,-1.93051,'https://www.thecompleteuniversityguide.co.uk/birmingham/'),(121,'Birmingham City University',650,52.4823,-1.88876,'https://www.thecompleteuniversityguide.co.uk/birmingham-city/'),(122,'Bishop Grosseteste University',379.83,53.2438,-0.536425,'https://www.thecompleteuniversityguide.co.uk/bishop-grosseteste/'),(123,'University of Bolton',0,53.5729,-2.43793,'https://www.thecompleteuniversityguide.co.uk/bolton/'),(124,'Bournemouth University',825,50.7424,-1.89564,'https://www.thecompleteuniversityguide.co.uk/bournemouth/'),(125,'BPP University',0,51.514,-0.0809164,'https://www.thecompleteuniversityguide.co.uk/bpp-university/'),(126,'University of Bradford',417.25,53.7908,-1.76346,'https://www.thecompleteuniversityguide.co.uk/bradford/'),(127,'University of Brighton',780,50.8421,-0.119365,'https://www.thecompleteuniversityguide.co.uk/brighton/'),(128,'University of Bristol',689.5,51.4578,-2.60844,'https://www.thecompleteuniversityguide.co.uk/bristol/'),(129,'Brunel University London',0,51.5329,-0.471229,'https://www.thecompleteuniversityguide.co.uk/brunel/'),(130,'The University of Buckingham',816.67,51.9962,-0.991869,'https://www.thecompleteuniversityguide.co.uk/buckingham/'),(131,'Buckinghamshire New University',646.42,51.6279,-0.753404,'https://www.thecompleteuniversityguide.co.uk/buckinghamshire-new/'),(132,'University of Cambridge',0,52.2004,0.120066,'https://www.thecompleteuniversityguide.co.uk/cambridge/'),(133,'Canterbury Christ Church University',0,51.2779,1.09066,'https://www.thecompleteuniversityguide.co.uk/canterbury-christ-church/'),(134,'University of Central Lancashire',476.67,53.7645,-2.70835,'https://www.thecompleteuniversityguide.co.uk/central-lancashire/'),(135,'University of Chester',710.67,53.2003,-2.89917,'https://www.thecompleteuniversityguide.co.uk/chester/'),(136,'University of Chichester',732.33,50.845,-0.772892,'https://www.thecompleteuniversityguide.co.uk/chichester/'),(137,'City',0,51.5278,-0.102545,'https://www.thecompleteuniversityguide.co.uk/city-university-london/'),(138,'Conservatoire for Dance and Drama',0,51.5258,-0.128796,'https://www.thecompleteuniversityguide.co.uk/conservatoire-for-dance-and-drama/'),(139,'The Courtauld Institute of Art',0,51.5116,-0.117395,'https://www.thecompleteuniversityguide.co.uk/the-courtauld-institute-of-art/'),(140,'Coventry University',566.17,52.4072,-1.50375,'https://www.thecompleteuniversityguide.co.uk/coventry/'),(141,'University of Cumbria',0,54.8909,-2.92223,'https://www.thecompleteuniversityguide.co.uk/cumbria/'),(142,'De Montfort University',618.42,52.6298,-1.13937,'https://www.thecompleteuniversityguide.co.uk/de-montfort/'),(143,'University of Derby',0,52.9385,-1.49652,'https://www.thecompleteuniversityguide.co.uk/derby/'),(144,'Durham University',656.92,54.7686,-1.57213,'https://www.thecompleteuniversityguide.co.uk/durham/'),(145,'University of East Anglia',0,52.6219,1.23918,'https://www.thecompleteuniversityguide.co.uk/east-anglia/'),(146,'University of East London',0,51.5076,0.0650809,'https://www.thecompleteuniversityguide.co.uk/east-london-uel/'),(147,'Edge Hill University',424.17,53.5597,-2.87385,'https://www.thecompleteuniversityguide.co.uk/edge-hill/'),(148,'University of Essex',780,51.8777,0.947207,'https://www.thecompleteuniversityguide.co.uk/essex/'),(149,'University of Exeter',1091.67,50.7352,-3.53428,'https://www.thecompleteuniversityguide.co.uk/exeter/'),(150,'Falmouth University',631.17,50.1492,-5.07068,'https://www.thecompleteuniversityguide.co.uk/falmouth-university/'),(151,'University of Gloucestershire',823.33,51.8871,-2.08873,'https://www.thecompleteuniversityguide.co.uk/gloucestershire/'),(152,'Goldsmiths',1243.67,51.4743,-0.035408,'https://www.thecompleteuniversityguide.co.uk/goldsmiths/'),(153,'University of Greenwich',910.5,51.484,-0.00499,'https://www.thecompleteuniversityguide.co.uk/greenwich/'),(154,'Guildhall School of Music and Drama',741,51.5197,-0.0908734,'https://www.thecompleteuniversityguide.co.uk/guildhall-school-of-music-and-drama/'),(155,'Harper Adams University',497.42,52.7794,-2.42713,'https://www.thecompleteuniversityguide.co.uk/harper-adams/'),(156,'University of Hertfordshire',794.92,51.7529,-0.242173,'https://www.thecompleteuniversityguide.co.uk/hertfordshire/'),(157,'University of Huddersfield',476.67,53.6428,-1.77809,'https://www.thecompleteuniversityguide.co.uk/huddersfield/'),(158,'The University of Hull',773.67,53.7737,-0.368078,'https://www.thecompleteuniversityguide.co.uk/hull/'),(159,'Imperial College London',1187.33,51.4988,-0.174877,'https://www.thecompleteuniversityguide.co.uk/imperial-college-london/'),(160,'Keele University',753.08,53.004,-2.2746,'https://www.thecompleteuniversityguide.co.uk/keele/'),(161,'The University of Kent',624.58,51.2985,1.07089,'https://www.thecompleteuniversityguide.co.uk/kent/'),(162,'Denmark Hill',1695.75,51.4684,-0.0960212,'https://www.thecompleteuniversityguide.co.uk/kings-college-london/'),(163,'Kingston University',1375,51.4032,-0.303488,'https://www.thecompleteuniversityguide.co.uk/kingston/'),(164,'Lancaster University',797.33,54.0105,-2.78691,'https://www.thecompleteuniversityguide.co.uk/lancaster/'),(165,'University of Leeds',0,53.8067,-1.55503,'https://www.thecompleteuniversityguide.co.uk/leeds/'),(166,'Leeds Arts University',513.33,53.8088,-1.55158,'https://www.thecompleteuniversityguide.co.uk/leeds-arts-university/'),(167,'Leeds Beckett University',816.58,53.8036,-1.54743,'https://www.thecompleteuniversityguide.co.uk/leeds-beckett/'),(168,'Leeds Trinity University ',450.25,53.8488,-1.64692,'https://www.thecompleteuniversityguide.co.uk/leeds-trinity/'),(169,'University of Leicester',0,52.6211,-1.12463,'https://www.thecompleteuniversityguide.co.uk/leicester/'),(170,'University of Lincoln',0,53.2279,-0.550193,'https://www.thecompleteuniversityguide.co.uk/lincoln/'),(171,'University of Liverpool',712.75,53.4059,-2.96557,'https://www.thecompleteuniversityguide.co.uk/liverpool/'),(172,'Liverpool Hope University',369,53.3908,-2.8923,'https://www.thecompleteuniversityguide.co.uk/liverpool-hope/'),(173,'The Liverpool Institute for Performing Arts',0,53.3996,-2.97231,'https://www.thecompleteuniversityguide.co.uk/liverpool-institute-for-performing-arts/'),(174,'Liverpool John Moores University',697.67,53.4093,-2.9906,'https://www.thecompleteuniversityguide.co.uk/liverpool-john-moores/'),(175,'The London Institute of Banking & Finance',0,51.5096,-0.084088,'https://www.thecompleteuniversityguide.co.uk/london-institute-of-banking-and-finance/'),(176,'London Metropolitan University',0,51.5516,-0.110715,'https://www.thecompleteuniversityguide.co.uk/london-metropolitan/'),(177,'LSE',2457,51.5144,-0.117377,'https://www.thecompleteuniversityguide.co.uk/london-school-of-economics/'),(178,'London South Bank University',0,51.4982,-0.102086,'https://www.thecompleteuniversityguide.co.uk/london-south-bank/'),(179,'Loughborough University ',582.08,52.7692,-1.22463,'https://www.thecompleteuniversityguide.co.uk/loughborough/'),(180,'The University of Manchester',619.58,53.4669,-2.23388,'https://www.thecompleteuniversityguide.co.uk/manchester/'),(181,'Manchester Metropolitan University',896.75,53.4711,-2.23862,'https://www.thecompleteuniversityguide.co.uk/manchester-metropolitan/'),(182,'Medway School of Pharmacy',0,51.3973,0.539073,'https://www.thecompleteuniversityguide.co.uk/medway-school-of-pharmacy/'),(183,'Middlesex University',585,51.5899,-0.229365,'https://www.thecompleteuniversityguide.co.uk/middlesex/'),(184,'New College of the Humanities',0,51.5194,-0.130519,'https://www.thecompleteuniversityguide.co.uk/new-college-of-the-humanities/'),(185,'Newcastle University',749.67,54.979,-1.61358,'https://www.thecompleteuniversityguide.co.uk/newcastle/'),(186,'Newman University ',0,52.433,-1.99421,'https://www.thecompleteuniversityguide.co.uk/newman-university/'),(187,'University of Northampton',553,52.2735,-0.882601,'https://www.thecompleteuniversityguide.co.uk/northampton/'),(188,'Northumbria University',309.31,54.9768,-1.6075,'https://www.thecompleteuniversityguide.co.uk/northumbria/'),(189,'Norwich University of the Arts',651.67,52.6303,1.2967,'https://www.thecompleteuniversityguide.co.uk/norwich-university-of-the-arts/'),(190,'The University of Nottingham',649,52.9387,-1.19517,'https://www.thecompleteuniversityguide.co.uk/nottingham/'),(191,'Nottingham Trent University',0,52.9585,-1.15268,'https://www.thecompleteuniversityguide.co.uk/nottingham-trent/'),(192,'The Open University',0,52.025,-0.708403,'https://www.thecompleteuniversityguide.co.uk/the-open-university/'),(193,'University of Oxford',0,51.7581,-1.26217,'https://www.thecompleteuniversityguide.co.uk/oxford/'),(194,'Oxford Brookes University',740.42,51.755,-1.22423,'https://www.thecompleteuniversityguide.co.uk/oxford-brookes/'),(195,'Pearson Business School',0,51.5167,-0.123263,'https://www.thecompleteuniversityguide.co.uk/pearson-college/'),(196,'University of Plymouth',582.5,50.3759,-4.13958,'https://www.thecompleteuniversityguide.co.uk/plymouth/'),(197,'Plymouth Marjon University',476.67,50.4211,-4.11043,'https://www.thecompleteuniversityguide.co.uk/plymouth-marjon/'),(198,'University of Portsmouth',513.33,50.7952,-1.09359,'https://www.thecompleteuniversityguide.co.uk/portsmouth/'),(199,'Queen Mary University of London ',0,51.5241,-0.0403745,'https://www.thecompleteuniversityguide.co.uk/queen-mary/'),(200,'Ravensbourne',815,51.5017,0.0057496,'https://www.thecompleteuniversityguide.co.uk/ravensbourne/'),(201,'University of Reading',0,51.4414,-0.941816,'https://www.thecompleteuniversityguide.co.uk/reading/'),(202,'University of Roehampton',761.75,51.458,-0.243287,'https://www.thecompleteuniversityguide.co.uk/roehampton/'),(203,'Rose Bruford College of Theatre and Performance',845,51.4391,0.106768,'https://www.thecompleteuniversityguide.co.uk/rose-bruford-college/'),(204,'Royal Academy of Music',759.67,51.5233,-0.151829,'https://www.thecompleteuniversityguide.co.uk/royal-academy-of-music/'),(205,'Royal Agricultural University',680.58,51.7093,-1.99465,'https://www.thecompleteuniversityguide.co.uk/royal-agricultural-university/'),(206,'The Royal Central School of Speech and Drama',0,51.5443,-0.174204,'https://www.thecompleteuniversityguide.co.uk/royal-central-school-of-speech-and-drama/'),(207,'Royal College of Music',0,51.4994,-0.177087,'https://www.thecompleteuniversityguide.co.uk/royal-college-of-music/'),(208,'Royal Holloway',548.25,51.4257,-0.563062,'https://www.thecompleteuniversityguide.co.uk/royal-holloway/'),(209,'Royal Northern College of Music',0,53.4685,-2.23674,'https://www.thecompleteuniversityguide.co.uk/royal-northern-college-of-music/'),(210,'Royal Veterinary College',0,51.5367,-0.13397,'https://www.thecompleteuniversityguide.co.uk/royal-veterinary-college/'),(211,'University of Salford',520.58,53.4846,-2.27076,'https://www.thecompleteuniversityguide.co.uk/salford/'),(212,'The University of Sheffield',699.42,53.3809,-1.48795,'https://www.thecompleteuniversityguide.co.uk/sheffield/'),(213,'Sheffield Hallam University',0,53.3782,-1.46589,'https://www.thecompleteuniversityguide.co.uk/sheffield-hallam/'),(214,'SOAS University of London',0,51.5224,-0.129259,'https://www.thecompleteuniversityguide.co.uk/soas-university-of-london/'),(215,'Solent University',667.33,50.9086,-1.40157,'https://www.thecompleteuniversityguide.co.uk/solent/'),(216,'University of Southampton',594.75,50.9357,-1.39664,'https://www.thecompleteuniversityguide.co.uk/southampton/'),(217,'St George\'s',736.67,51.4272,-0.174503,'https://www.thecompleteuniversityguide.co.uk/st-georges/'),(218,'St Mary\'s University',806.67,51.437,-0.33507,'https://www.thecompleteuniversityguide.co.uk/st-marys/'),(219,'Staffordshire University',406.25,53.0091,-2.17614,'https://www.thecompleteuniversityguide.co.uk/staffordshire/'),(220,'University of Suffolk',0,52.0522,1.16334,'https://www.thecompleteuniversityguide.co.uk/suffolk/'),(221,'University of Sunderland',642.75,51.5002,-0.0142346,'https://www.thecompleteuniversityguide.co.uk/sunderland/'),(222,'The University of Surrey',1451.67,51.2422,-0.590542,'https://www.thecompleteuniversityguide.co.uk/surrey/'),(223,'University of Sussex',497.33,50.8671,-0.087914,'https://www.thecompleteuniversityguide.co.uk/sussex/'),(224,'Teesside University',498.33,54.5708,-1.23522,'https://www.thecompleteuniversityguide.co.uk/teesside/');
/*!40000 ALTER TABLE `cities.2018.08.06` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__bookmark`
--

DROP TABLE IF EXISTS `pma__bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__bookmark`
--

LOCK TABLES `pma__bookmark` WRITE;
/*!40000 ALTER TABLE `pma__bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__central_columns`
--

DROP TABLE IF EXISTS `pma__central_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin,
  PRIMARY KEY (`db_name`,`col_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__central_columns`
--

LOCK TABLES `pma__central_columns` WRITE;
/*!40000 ALTER TABLE `pma__central_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__central_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__column_info`
--

DROP TABLE IF EXISTS `pma__column_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__column_info` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__column_info`
--

LOCK TABLES `pma__column_info` WRITE;
/*!40000 ALTER TABLE `pma__column_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__column_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__designer_settings`
--

DROP TABLE IF EXISTS `pma__designer_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__designer_settings`
--

LOCK TABLES `pma__designer_settings` WRITE;
/*!40000 ALTER TABLE `pma__designer_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__designer_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__export_templates`
--

DROP TABLE IF EXISTS `pma__export_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__export_templates` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__export_templates`
--

LOCK TABLES `pma__export_templates` WRITE;
/*!40000 ALTER TABLE `pma__export_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__export_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__favorite`
--

DROP TABLE IF EXISTS `pma__favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__favorite`
--

LOCK TABLES `pma__favorite` WRITE;
/*!40000 ALTER TABLE `pma__favorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__history`
--

DROP TABLE IF EXISTS `pma__history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`,`db`,`table`,`timevalue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__history`
--

LOCK TABLES `pma__history` WRITE;
/*!40000 ALTER TABLE `pma__history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__navigationhiding`
--

DROP TABLE IF EXISTS `pma__navigationhiding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__navigationhiding`
--

LOCK TABLES `pma__navigationhiding` WRITE;
/*!40000 ALTER TABLE `pma__navigationhiding` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__navigationhiding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__pdf_pages`
--

DROP TABLE IF EXISTS `pma__pdf_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`page_nr`),
  KEY `db_name` (`db_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__pdf_pages`
--

LOCK TABLES `pma__pdf_pages` WRITE;
/*!40000 ALTER TABLE `pma__pdf_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__pdf_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__recent`
--

DROP TABLE IF EXISTS `pma__recent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__recent`
--

LOCK TABLES `pma__recent` WRITE;
/*!40000 ALTER TABLE `pma__recent` DISABLE KEYS */;
INSERT INTO `pma__recent` VALUES ('andyholyer','[{\"db\":\"DAMP_ajh\",\"table\":\"cities\"}]');
/*!40000 ALTER TABLE `pma__recent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__relation`
--

DROP TABLE IF EXISTS `pma__relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  KEY `foreign_field` (`foreign_db`,`foreign_table`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__relation`
--

LOCK TABLES `pma__relation` WRITE;
/*!40000 ALTER TABLE `pma__relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__savedsearches`
--

DROP TABLE IF EXISTS `pma__savedsearches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__savedsearches` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__savedsearches`
--

LOCK TABLES `pma__savedsearches` WRITE;
/*!40000 ALTER TABLE `pma__savedsearches` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__savedsearches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__table_coords`
--

DROP TABLE IF EXISTS `pma__table_coords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float unsigned NOT NULL DEFAULT '0',
  `y` float unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__table_coords`
--

LOCK TABLES `pma__table_coords` WRITE;
/*!40000 ALTER TABLE `pma__table_coords` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__table_coords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__table_info`
--

DROP TABLE IF EXISTS `pma__table_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`db_name`,`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__table_info`
--

LOCK TABLES `pma__table_info` WRITE;
/*!40000 ALTER TABLE `pma__table_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__table_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__table_uiprefs`
--

DROP TABLE IF EXISTS `pma__table_uiprefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`username`,`db_name`,`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__table_uiprefs`
--

LOCK TABLES `pma__table_uiprefs` WRITE;
/*!40000 ALTER TABLE `pma__table_uiprefs` DISABLE KEYS */;
INSERT INTO `pma__table_uiprefs` VALUES ('andyholyer','DAMP_ajh','cities','{\"sorted_col\":\"`id` ASC\"}','2018-08-21 11:12:54');
/*!40000 ALTER TABLE `pma__table_uiprefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__tracking`
--

DROP TABLE IF EXISTS `pma__tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`db_name`,`table_name`,`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__tracking`
--

LOCK TABLES `pma__tracking` WRITE;
/*!40000 ALTER TABLE `pma__tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__userconfig`
--

DROP TABLE IF EXISTS `pma__userconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__userconfig`
--

LOCK TABLES `pma__userconfig` WRITE;
/*!40000 ALTER TABLE `pma__userconfig` DISABLE KEYS */;
INSERT INTO `pma__userconfig` VALUES ('andyholyer','2018-08-06 14:42:05','{\"collation_connection\":\"utf8mb4_unicode_ci\"}');
/*!40000 ALTER TABLE `pma__userconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__usergroups`
--

DROP TABLE IF EXISTS `pma__usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N',
  PRIMARY KEY (`usergroup`,`tab`,`allowed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__usergroups`
--

LOCK TABLES `pma__usergroups` WRITE;
/*!40000 ALTER TABLE `pma__usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__users`
--

DROP TABLE IF EXISTS `pma__users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`,`usergroup`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__users`
--

LOCK TABLES `pma__users` WRITE;
/*!40000 ALTER TABLE `pma__users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-21 13:13:05

