<?php

/* Connect to the MySQL server, and put the resulting database connection object in $mysqli 
   In any live situation the unsername and password should be stored in a (non-web-accesible)
   file and you should use include() to read these into your main script.
   
   As an aside, it's a very bad idea in general to use your initials in any code you write - it gets especially 
   confusing once you've left the organization and someone else whose initials are not AJH has to maintain the thing
*/
$mysqli = new mysqli(
	/*
	  The address where the MySQL server is running - "localhost" == "This computer"
	  */
	"localhost",
	/*
	  The MySQL username - as I said, you should keep this more secure in a live environment
	  */
	"DAMP_ajh",
	/*
	  The password for the above username - definitely keep this secure!
	  */
	"ie7Li8$0",
	/*
	  The particular database on the MySQL server to connect to - this doesn't have to be the same as the username, 
	  in fact it usually shouldn't be the same!
	  */
	"DAMP_ajh"
);
/* Check if the connect attempt returned an error. You should always be ultra paranoid about the result of external calls */
if ($mysqli->connect_errno) {
	/* Display an error message so we can try to figure out what went wrong */
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	/* Drop out of the script with an error status */
	exit(1);
}

/* "cities" is the table in the database where I store the records for each University.
   It probably isn't very well named :-)
   The query (assuming it works) will return all the records in that table.
   You can prepare a different query string to either:
   		Return some (but not all) records, or
		Return some (but not all) fields in each record
   (Or you can even do both).
   Since that's what databases are designed to do, you should find getting the database server to filter results is
   faster and more efficient in terms of memory use etc. than doing it in a program script.
   
   If the query fails, $result will be set to FALSE and the if() clause will fail. 
*/
if ($result = $mysqli->query("SELECT * FROM cities")) {

	/* 
		We've got a valid set of records returned, so output the result as JSON
		
		First, return a "Content-Type" header so the browser knows what it's dealing with:
		(It would probably be slightly better style to defer this line until after we've done the heavy conversion work in the 
		next few line of code)...
	*/
	header("Content-Type: application/json");

	/*
		Variable to hold the data structures which will be output as JSON.
		I've created an empty array which we'll fill in a few moments..
	*/
	$output = array();
	
	/*
		Fetch the next record from the $result object, and return it as an associative array (look it up!)
		Put each result in $row
		The while() loop will repeat until we reach the last record
	*/
	while ($row = $result->fetch_assoc()) {

		/*
			Build the next record in the variable $data, from the entries in the assoc. array $row.
			Since this creates a new array structure for each row, and then lets it get garbage collected
			afterwards, this is relatively inefficient, but it will do for now, and the logic is clearer
			than a more efficient way would be. In this context, it works.
		*/
		$data = array(
			/* Just copy "label" and "cost" over */
			label => $row['label'],
			cost => $row["cost"],
			/* Build a new "position" element for the supplied "lat" and "lng" values
			   (In my scraping code I scraped the postcode of the University and then did a 
			   call to GoogleMaps.geocode to convert this into lattitude and longitude)
			*/
			position => array(
				/* 'lat' and 'lng' have to be numbers, not strings, otherwise the googlemaps code complains */
				lat => floatval($row['lat']),
				lng => floatval($row['lng'])
			),
			url => $row['url'],
			/* The "icon" element will have some structure added in the Javascript front end, but for now it's empty */
			icon => array(),
		);

		/* Finally, push the value onto the end of our temporary array */
		array_push( $output, $data );

	}
	
	/* Now we have a list of associative arrays, one per record (so, one for each university), and we just output this
	   in JSON format. You could fairly easily just do this with string functions, but if you can, it's always best to
	   let the library do this bit, because it's less likely to make errors than you are.
	 */
	echo json_encode($output);
	
} else {
	/*
		If we've got here, the $result returned by the query has failed, so we may get an error returned,
		but there's nothnig else to do but return that error
	*/
	echo "SELECT request failed: (" . $mysqli->errono . ") " . $mysqli->error;
	exit(1);
}
?>