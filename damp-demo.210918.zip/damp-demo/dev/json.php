<?php

$mysqli = new mysqli("localhost", "DAMP_ajh", "ie7Li8$0", "DAMP_ajh");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

if ($result = $mysqli->query("SELECT * FROM cities")) {

	header("Content-Type: application/json");

	$output = array();
	
	while ($row = $result->fetch_assoc()) {

		$data = array(
			label => $row['label'],
			cost => $row["cost"],
			position => array(
				lat => floatval($row['lat']),
				lng => floatval($row['lng'])
			),
			url => $row['url'],
			icon => array(),
		);

		array_push( $output, $data );

	}
	
	echo json_encode($output);
	
} else {
	echo "SELECT request failed: (" . $mysqli->errono . ") " . $mysqli->error;
}
?>